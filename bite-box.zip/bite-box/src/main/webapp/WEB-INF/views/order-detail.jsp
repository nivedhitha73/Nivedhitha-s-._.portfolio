<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="header.jsp"><jsp:param name="title" value="Order"/></jsp:include>
<div class="row between"><h1>Order #${order.id}</h1><span class="badge ${order.status}">${order.status}</span></div>
<p class="muted"><fmt:formatDate value="${order.createdAt}" pattern="d MMM yyyy, HH:mm"/> &middot; for <c:out value="${order.customer}"/></p>
<div class="scroll"><table>
  <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead>
  <tbody><c:forEach var="l" items="${order.lines}">
    <tr><td><c:out value="${l.name}"/></td><td>$<fmt:formatNumber value="${l.price}" pattern="0.00"/></td><td>${l.qty}</td><td>$<fmt:formatNumber value="${l.total}" pattern="0.00"/></td></tr>
  </c:forEach></tbody>
  <tfoot><tr><td colspan="3"><strong>Total</strong></td><td><strong>$<fmt:formatNumber value="${order.total}" pattern="0.00"/></strong></td></tr></tfoot>
</table></div>
<c:if test="${not empty order.note}"><p>Note: <c:out value="${order.note}"/></p></c:if>
<div class="row">
  <form method="post" action="orders"><input type="hidden" name="action" value="reorder"><input type="hidden" name="id" value="${order.id}"><button type="submit">Order again</button></form>
  <c:if test="${order.status == 'PLACED'}"><form method="post" action="orders" onsubmit="return confirm('Cancel this order?')"><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="${order.id}"><button class="ghost danger" type="submit">Cancel order</button></form></c:if>
  <a class="btn ghost" href="orders">All orders</a>
</div>
<jsp:include page="footer.jsp"/>
