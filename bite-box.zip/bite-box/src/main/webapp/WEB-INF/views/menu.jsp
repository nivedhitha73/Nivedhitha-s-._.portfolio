<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="header.jsp"><jsp:param name="title" value="Menu"/></jsp:include>
<form class="search" method="get" action="menu">
  <input name="q" value="<c:out value='${q}'/>" placeholder="Search dishes">
  <input type="hidden" name="category" value="<c:out value='${selected}'/>">
  <button type="submit">Search</button>
</form>
<div class="chips">
  <a class="${empty selected ? 'on' : ''}" href="menu">All</a>
  <c:forEach var="cat" items="${categories}"><a class="${cat == selected ? 'on' : ''}" href="menu?category=${cat}"><c:out value="${cat}"/></a></c:forEach>
</div>
<c:if test="${not empty recentItems}">
  <h2>Recently viewed</h2>
  <div class="strip"><c:forEach var="r" items="${recentItems}"><a href="item?id=${r.id}">${r.emoji} <c:out value="${r.name}"/></a></c:forEach></div>
</c:if>
<h2>${empty selected ? 'All dishes' : selected}</h2>
<c:if test="${empty items}"><p class="empty">Nothing matches that search. Try another word or category.</p></c:if>
<div class="grid">
<c:forEach var="i" items="${items}">
  <article class="card">
    <a class="emoji" href="item?id=${i.id}">${i.emoji}</a>
    <h3><a href="item?id=${i.id}"><c:out value="${i.name}"/></a></h3>
    <p class="muted"><c:out value="${i.description}"/></p>
    <div class="row between">
      <strong>$<fmt:formatNumber value="${i.price}" pattern="0.00"/></strong>
      <form method="post" action="cart"><input type="hidden" name="action" value="add"><input type="hidden" name="id" value="${i.id}"><button type="submit">Add to cart</button></form>
    </div>
  </article>
</c:forEach>
</div>
<jsp:include page="footer.jsp"/>
