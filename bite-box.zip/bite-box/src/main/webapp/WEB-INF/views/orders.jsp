<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="header.jsp"><jsp:param name="title" value="My orders"/></jsp:include>
<h1>Recent orders</h1>
<c:if test="${empty orders}"><p class="empty">No orders yet. <a href="menu">Pick something from the menu</a>.</p></c:if>
<c:forEach var="o" items="${orders}">
  <article class="card">
    <div class="row between">
      <h3><a href="orders?id=${o.id}">Order #${o.id}</a></h3>
      <span class="badge ${o.status}">${o.status}</span>
    </div>
    <p class="muted"><fmt:formatDate value="${o.createdAt}" pattern="d MMM yyyy, HH:mm"/> &middot; ${o.itemCount} items &middot; $<fmt:formatNumber value="${o.total}" pattern="0.00"/></p>
    <p><c:forEach var="l" items="${o.lines}" varStatus="st"><c:out value="${l.qty} x ${l.name}"/>${st.last ? '' : ', '}</c:forEach></p>
    <form method="post" action="orders"><input type="hidden" name="action" value="reorder"><input type="hidden" name="id" value="${o.id}"><button class="ghost" type="submit">Order again</button></form>
  </article>
</c:forEach>
<jsp:include page="footer.jsp"/>
