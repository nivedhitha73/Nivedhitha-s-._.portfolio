<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><c:out value="${param.title}"/> | Bite Box</title>
<link rel="stylesheet" href="css/style.css"><script src="js/theme.js"></script></head>
<body>
<header class="bar">
  <a class="brand" href="menu">Bite Box</a>
  <nav>
    <a href="menu">Menu</a>
    <a href="orders">My orders</a>
    <a href="cart">Cart (${empty cart ? 0 : cart.size()})</a>
  </nav>
  <button id="modeBtn" class="ghost" type="button" aria-label="Toggle dark mode">Dark mode</button>
</header>
<main>
<c:if test="${not empty flash}"><p class="flash" role="status"><c:out value="${flash}"/></p><c:remove var="flash" scope="session"/></c:if>
