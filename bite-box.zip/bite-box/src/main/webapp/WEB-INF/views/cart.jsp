<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="header.jsp"><jsp:param name="title" value="Cart"/></jsp:include>
<h1>Your cart</h1>
<c:choose>
<c:when test="${empty lines}"><p class="empty">Your cart is empty. <a href="menu">Browse the menu</a> to add dishes.</p></c:when>
<c:otherwise>
<div class="scroll"><table>
  <thead><tr><th>Item</th><th>Price</th><th>Quantity</th><th>Total</th><th></th></tr></thead>
  <tbody>
  <c:forEach var="l" items="${lines}">
    <tr>
      <td><c:out value="${l.name}"/></td>
      <td>$<fmt:formatNumber value="${l.price}" pattern="0.00"/></td>
      <td><form method="post" action="cart" class="row">
        <input type="hidden" name="action" value="set"><input type="hidden" name="id" value="${l.itemId}">
        <input class="narrow" type="number" name="qty" value="${l.qty}" min="0" max="20"><button class="ghost" type="submit">Update</button></form></td>
      <td>$<fmt:formatNumber value="${l.total}" pattern="0.00"/></td>
      <td><form method="post" action="cart"><input type="hidden" name="action" value="remove"><input type="hidden" name="id" value="${l.itemId}"><button class="link danger" type="submit">Remove</button></form></td>
    </tr>
  </c:forEach>
  </tbody>
  <tfoot><tr><td colspan="3"><strong>Order total</strong></td><td colspan="2"><strong>$<fmt:formatNumber value="${total}" pattern="0.00"/></strong></td></tr></tfoot>
</table></div>
<h2>Checkout</h2>
<form class="card form" method="post" action="orders">
  <input type="hidden" name="action" value="place">
  <label>Your name<input name="customer" required maxlength="80"></label>
  <label>Phone (optional)<input name="phone" maxlength="20"></label>
  <label>Note for the kitchen (optional)<input name="note" maxlength="200"></label>
  <div class="row"><button type="submit">Place order</button></div>
</form>
<form method="post" action="cart"><input type="hidden" name="action" value="clear"><button class="link danger" type="submit">Empty cart</button></form>
</c:otherwise>
</c:choose>
<jsp:include page="footer.jsp"/>
