<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<jsp:include page="header.jsp"><jsp:param name="title" value="${item.name}"/></jsp:include>
<article class="card detail">
  <div class="emoji big">${item.emoji}</div>
  <h1><c:out value="${item.name}"/></h1>
  <p class="muted"><c:out value="${item.category}"/></p>
  <p><c:out value="${item.description}"/></p>
  <p><strong>$<fmt:formatNumber value="${item.price}" pattern="0.00"/></strong></p>
  <form method="post" action="cart" class="row">
    <input type="hidden" name="action" value="add"><input type="hidden" name="id" value="${item.id}">
    <label class="qty">Quantity <input type="number" name="qty" value="1" min="1" max="20"></label>
    <button type="submit">Add to cart</button>
    <a class="btn ghost" href="menu">Back to menu</a>
  </form>
</article>
<jsp:include page="footer.jsp"/>
